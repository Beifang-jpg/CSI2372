
#ifndef PERSON_H
#define PERSON_H
#include <iostream>
#include <string>
#include <stdlib.h>

using namespace std;

class Organization;
 
/**
Class Person:  Create  Person, used to add organizations to a person
Private variable: name, age and others to define


Add all missing methods
*/
class Person {
    int dim;
    string name;
    int age;
    int size = 0;
  
};

#endif