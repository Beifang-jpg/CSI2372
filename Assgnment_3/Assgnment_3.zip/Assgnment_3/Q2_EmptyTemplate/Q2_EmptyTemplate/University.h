
#ifndef UNIVERSITY_H 
#define UNIVERSITY_H 

#include "Organization.h"



class University : public Organization {
    float tuition;

   
};

#endif

