
#include "Person.h"
#include "Organization.h"
#include "University.h"


Person::Person(std::string n, int a) {
    name = n;

};




}